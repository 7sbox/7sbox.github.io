# Remote Wake Up

一个面向 Windows 的局域网唤醒（Wake-on-LAN）桌面工具。使用 **C++20 + 原生 Win32 API** 开发，窗口与控件由 **GDI+** 自绘，不依赖 Qt、Electron 或 .NET 运行时。

![Remote Wake Up 主界面](docs/screenshots/main.png)

## 功能

- 管理多台电脑：名称、分组标签、MAC 地址、IP/域名、WOL 端口、广播地址。
- 一键发送 Wake-on-LAN 魔术包：
  - 标准 102 字节负载（6 个 `0xFF` + MAC 重复 16 次）。
  - 同时发送到目标地址和广播地址，每次 3 份以提高可靠性。
  - 目标地址暂时无法解析时，自动回退到广播唤醒。
- 左侧分组主机列表、右侧主机详情、发送结果 Toast。
- 主机名左侧实时在线状态圆点：每 4 秒异步 ICMP 探测，绿色在线、灰色离线或尚未探测。
- 编辑窗口内可扫描局域网主机：通过 UDP 探测触发 ARP 解析，约 1–2 秒列出在线设备，并用 NetBIOS NBSTAT 查询显示主机名；双击结果自动填表。
- 系统托盘：左键打开主窗口；右键菜单可直接唤醒指定主机、打开 Preferences 或退出。
- Preferences 中可配置：界面语言、关闭窗口到托盘、开机自动运行、启动时最小化到托盘。
- 语言支持：内置英文；外挂简体中文、繁体中文、日语、韩语、西班牙语、法语、德语、葡萄牙语、俄语共 9 种语言文件；默认跟随 Windows 显示语言，缺失文件时回退内置英文。
- 正常启动时窗口居中并置于前台；从托盘隐藏状态再次启动会恢复并唤起已有窗口。
- 若开启“启动时最小化到托盘”，程序会以托盘模式启动并显示提示气泡；再次普通启动可恢复窗口。
- 深色自绘标题栏、无边框窗口、自绘主菜单与对话框，支持高 DPI。
- 配置以 JSON 保存到 `%APPDATA%\RemoteWakeUp\config.json`，采用临时文件 + 原子替换写入。
- 单实例运行：重复启动会唤起已经运行的窗口。

## 界面

| 主界面 | 编辑主机 |
| --- | --- |
| ![主界面](docs/screenshots/main.png) | ![编辑主机](docs/screenshots/editor-details.png) |

| 局域网扫描 | 首选项（语言选择） |
| --- | --- |
| ![局域网扫描](docs/screenshots/editor-network.png) | ![首选项](docs/screenshots/preferences.png) |

| 托盘菜单 | 空状态 |
| --- | --- |
| ![托盘菜单](docs/screenshots/tray-menu.png) | ![空状态](docs/screenshots/empty.png) |

| 中文界面 | 法语界面 |
| --- | --- |
| ![中文界面](docs/screenshots/preferences-zh.png) | ![法语界面](docs/screenshots/main-fr.png) |

| 设备列表 | 设备详情（文件 / 电源 / 音频） |
| --- | --- |
| ![设备列表](docs/screenshots/netlink-devices-list.png) | ![设备详情](docs/screenshots/netlink-device.png) |

整体布局参考了需求中的 macOS 截图：左侧主机列表、右侧详情、独立编辑面板和系统托盘菜单。Windows 版本采用原生窗口行为，并增加自绘深色标题栏、Windows 通知区域和注册表开机启动。

## 快捷操作

| 操作 | 快捷键 |
| --- | --- |
| 添加主机 | `Ctrl + N` |
| 编辑当前主机 | `Ctrl + E` / `F2` |
| 唤醒当前主机 | `Enter` / 双击主机 |
| 删除当前主机 | `Delete` |
| 选择主机 | `↑` / `↓` |
| 打开 Preferences | `Ctrl + ,` |
| 关闭对话框 | `Esc` |
| 确认对话框操作 | `Enter` |

## 快速开始

### 直接运行构建产物

```powershell
.\build\bin\RemoteWakeUp.exe
```

首次运行没有主机，点击右侧 **Add a Host**，或按 `Ctrl + N`。

想直接查看带示例数据的界面：

```powershell
.\build\bin\RemoteWakeUp.exe --config .\demo\config.json
```

在 **Preferences** 中勾选 “Start minimized to the notification area”，或使用命令行参数，以托盘模式启动：

```powershell
.\build\bin\RemoteWakeUp.exe --minimized
```

### 添加并唤醒一台电脑

1. 在目标电脑的 BIOS/UEFI 和网卡驱动中启用 Wake-on-LAN。
2. 记下目标网卡的 MAC 地址，并确认目标电脑使用有线网络。
3. 在本工具中点击 `+`，填写 MAC 地址；IP/域名和广播地址可留空。
4. 选中主机后点击 **Wake**。局域网内会发送魔术包。

> Wake-on-LAN 只能从睡眠/休眠状态唤醒目标电脑；彻底关机后是否可唤醒取决于主板和网卡的“ErP/深度睡眠”设置。

## 界面语言

Preferences 的 **INTERFACE LANGUAGE** 使用下拉列表选择：

- **Automatic**：根据 Windows 显示语言自动选择。
  - 简体中文 → `lang/zh-CN.json`
  - 繁体中文 → `lang/zh-TW.json`
  - 日语 → `lang/ja.json`
  - 韩语 → `lang/ko.json`
  - 西班牙语 → `lang/es.json`
  - 法语 → `lang/fr.json`
  - 德语 → `lang/de.json`
  - 葡萄牙语 → `lang/pt.json`
  - 俄语 → `lang/ru.json`
  - 英文或其他语言 → 内置英文
- **English**：使用编译进程序的内置英文。
- 其余 9 项分别加载对应外挂语言文件。

![语言下拉菜单](docs/screenshots/language-dropdown.png)

外挂语言文件位于可执行文件旁边的 `lang` 目录。若所选语言文件不存在、格式损坏，或某个键缺失，程序会回退到内置英文，不会出现空白界面。

```text
lang/
  zh-CN.json   简体中文
  zh-TW.json   繁體中文
  ja.json      日本語
  ko.json      한국어
  es.json      Español
  fr.json      Français
  de.json      Deutsch
  pt.json      Português
  ru.json      Русский
```

语言文件为 UTF-8 JSON：

```json
{
  "code": "zh-CN",
  "name": "简体中文",
  "version": 1,
  "strings": {
    "app.title": "网络唤醒",
    "main.wake": "唤醒"
  }
}
```

修改语言文件后重新启动程序即可生效。`lang/` 目录会随发布包一起分发。

## 构建

### 依赖

- CMake 3.20+
- Ninja（推荐）
- MinGW-w64（已在 GCC 15.2 / MSYS2 环境验证，需要 `windres`）
- Windows 10 或 Windows 11

### 命令

```powershell
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
```

产物：

```text
build/bin/RemoteWakeUp.exe
```

MinGW 构建使用 `-static -static-libgcc -static-libstdc++`，可脱离 MinGW 运行库直接分发。CMake 也保留了 `RWU_BUILD_APP=OFF`，只构建核心库和测试：

```powershell
cmake -S . -B build-core -G Ninja -DRWU_BUILD_APP=OFF
cmake --build build-core
```

### 测试

```powershell
ctest --test-dir build --output-on-failure
```

测试包含：

- **wakecore_tests**：MAC 解析、魔术包内容、UDP 回环发送、JSON、UTF-8、输入校验、配置读写/损坏恢复、NetBIOS NBSTAT 报文解析、扫描网段计算、ICMP 在线探测（回环地址）、语言文件完整性/回退/语言代码映射。
- **ui_smoke**：启动真实 Win32 窗口并确认正常启动可见；打开编辑框、检查字段、修改主机名并保存、验证 JSON 落盘；点击 Wake 在 UDP 回环端口接收并校验 102 字节魔术包；验证模态窗口打开时宿主窗口没有白色系统边框；关闭到托盘、重复启动唤起已有窗口；验证 `startMinimized` 启动只显示托盘、普通启动可恢复窗口。该测试需要 Windows 交互式桌面。

## 配置格式

默认路径：`%APPDATA%\RemoteWakeUp\config.json`

```json
{
  "version": 1,
  "settings": {
    "defaultPort": 9,
    "broadcast": "192.168.3.255",
    "closeToTray": true,
    "startWithWindows": false,
    "startMinimized": false,
    "language": "auto"
  },
  "hosts": [
    {
      "id": "F4D07D8C-31B5-4D1A-A2E1-4E9A4F4E1A01",
      "name": "Lenovo",
      "label": "Linux",
      "mac": "FC:4D:D4:3C:28:CF",
      "address": "192.168.3.4",
      "broadcast": "192.168.3.255",
      "port": 9
    }
  ]
}
```

- `address` 为空时只使用广播地址；每台主机可覆盖全局广播地址。
- `label` 用于左侧列表分组；为空时归入 `Other`（没有其他分组时显示为 `Hosts`）。
- `startMinimized` 为 `true` 时，程序启动后只显示托盘图标；`startWithWindows` 控制是否写入当前用户的 Windows 启动项。
- `language` 支持 `auto`、`en`、`zh-CN`、`zh-TW`、`ja`、`ko`、`es`、`fr`、`de`、`pt`、`ru`；语言文件位于可执行文件旁的 `lang` 目录。
- 配置文件损坏时会自动复制一份 `.broken-<tick>` 备份，并以默认设置继续启动。

## 设计说明

### 为什么不用现成 UI 框架

需求明确要求 C++ + Win32 API。项目直接使用：

- `CreateWindowEx`、`WndProc`、`WM_PAINT` 等窗口机制。
- `GDI+` 绘制圆角卡片、渐变地球图标、文字和矢量操作图标。
- `DwmSetWindowAttribute`、无边框窗口与 `WM_NCHITTEST` 实现深色自绘标题栏和拖动/缩放。
- 原生 `EDIT` 控件配合 `WM_CTLCOLOREDIT` 实现可输入且风格一致的文本框。
- 自绘 `TrackPopupMenu` 菜单项和 `Shell_NotifyIcon` 托盘菜单。

### 局域网扫描

扫描不发送魔术包，避免误唤醒。实现方式：

1. 枚举活动 IPv4 网卡，取本机 /24 网段。
2. 向每个地址的 UDP 端口 `32767` 发送一个很小的探测数据报，让 Windows 主动进行 ARP 解析。
3. 等待相邻缓存稳定后读取 `GetIpNetTable`，过滤掉组播、广播和本机地址。
4. 对找到的主机并行发送 NetBIOS Node Status（NBSTAT）查询，解析唯一工作站名称；组名和 `__MSBROWSE__` 会被忽略。
5. 结果按 IPv4 排序，双击表格行即可回填 MAC/IP。

在常见 /24 局域网中扫描耗时约 1–2 秒；不会因为逐个 `SendARP` 超时而等待几十秒。

### 目录结构

```text
src/core/       无 UI 依赖的核心：WOL、MAC、JSON、配置、扫描、NetBIOS、校验、本地化、SHA-256
src/net/        互联子系统：发现、会话、连接池、入站服务、状态、文件传输、音频、远程执行
src/ui/         GDI+ 绘制、主窗口、编辑框、首选项、托盘菜单
src/app/        App 生命周期、托盘、单实例、入口点
assets/         图标、manifest、版本资源
lang/           外挂语言文件（简体中文、繁体中文、日语、韩语、西班牙语、法语、德语、葡萄牙语、俄语）
tests/          核心单元测试 + Win32 UI 冒烟测试
demo/           示例配置
docs/screenshots/
docs/netlink/   互联功能文档（需求 / 架构 / 计划 / 开源选型 / 安全说明 / 执行台账）
```

## 设备互联

安装了本程序的设备之间可以直接互传文件、查看对方状态、把对方的系统声音混到本机播放、远程重启或关机，以及（默认关闭、需显式授权）运行对方白名单里的脚本。

所有能力都建立在**配对**之上：未配对的设备在 TLS 握手之后立刻被断开，连一条消息都发不出去。配对只授予**身份**，不授予任何权限——每项能力还要单独在配置里打开。

| 能力 | 使用方式 | 默认状态 |
| --- | --- | --- |
| 传送文件 | 设备详情「发送文件…」，或把文件/文件夹拖到窗口上（发给当前选中设备） | 开启 |
| 查看状态 | 选中设备即自动订阅，显示 CPU / 内存 / 网络折线图与磁盘 | 开启 |
| 听取系统声音 | 设备详情「听这台机器的声音」，每路可单独调音量、静音、solo | 开启 |
| 远程电源 | 设备详情「重启」「关机」按钮，确认后目标 **30 秒倒计时**再执行；「取消」可在倒计时归零前中止。需要对方授予 `exec` 能力 | 跟随 `exec` 能力（默认不授予） |
| 远程执行脚本 | 设备详情「远程脚本」列出对方允许你运行的条目，点击运行并实时看输出；白名单在托盘菜单「远程执行白名单」维护 | **关闭**，且每个条目还需锁定 + 勾选允许的设备 |

远程电源与远程执行共用 `exec` 能力：能在这台机器上跑程序的设备才可能关掉它，不另设一个容易和实际权限对不上的能力位。倒计时期间目标机显示自己的系统警告，发起方和目标方的本程序都能取消。每次请求（含被拒绝的）都会写进审计日志 `netlink-audit.jsonl`。

技术细节见 [`docs/netlink/`](docs/netlink/README.md)：需求、架构、执行计划、开源选型、[安全说明](docs/netlink/05-security.md)、[执行台账](docs/netlink/STATUS.md)。

![总体架构](docs/netlink/diagrams/architecture.png)

![数据流](docs/netlink/diagrams/dataflow.png)

### 互联配置

配置在同一个 `config.json` 的 `netlink` 块里：

```json
{
  "netlink": {
    "enabled": true,
    "deviceId": "00112233445566778899aabbccddeeff",
    "deviceName": "STUDY-PC",
    "port": 47810,
    "discoveryPort": 47811,
    "receivePolicy": "ask",
    "receiveDir": "C:\\Users\\me\\Downloads\\RemoteWakeUp",
    "maxTransferKb": 0,
    "peers": [
      {
        "id": "ffeeddccbbaa99887766554433221100",
        "name": "KITCHEN-PC",
        "address": "192.168.1.50",
        "spkiSha256": "…64 位十六进制…",
        "caps": { "file": true, "exec": false, "stat": true, "audio": true },
        "pairedAt": 1700000000
      }
    ],
    "execEnabled": false,
    "execAllow": [],
    "stats": { "intervalMs": 1000, "includeTopProcesses": false },
    "audio": { "bitrateKbps": 96, "frameMs": 20, "jitterTargetMs": 120 }
  }
}
```

| 字段 | 含义 |
| --- | --- |
| `enabled` | 总开关，默认 `true`。关闭后不监听端口、不发送发现广播 |
| `deviceId` | 本机 32 位十六进制设备 id，首次启动自动生成，**不要手工修改** |
| `deviceName` | 广播给对端的名字，默认取计算机名 |
| `port` / `discoveryPort` | 服务端口（TCP，默认 47810）与发现端口（UDP 组播，默认 47811）；被占用时会自动向后顺延并在状态栏显示实际端口 |
| `autoAuthorize` | **默认 `true`**：发现到运行本程序的设备就自动配对并授权，双方各自执行同一策略；`autoAuthorizeFile/Stat/Audio/Exec` 分别控制四项能力，**远程执行默认不自动授予**。共享网络请设为 `false` |\n| `receivePolicy` | `ask` 每次询问 / `accept` 自动接收 / `reject` 全部拒绝 |
| `receiveDir` | 接收目录，默认 `%USERPROFILE%\Downloads\RemoteWakeUp` |
| `maxTransferKb` | 单个传输大小上限，`0` 表示用内置默认 |
| `peers` | 已配对设备。`spkiSha256` 是固定用的证书指纹，`caps` 是该设备被授予的能力；**手写配置时字段名必须是 `id`/`spkiSha256`/`caps`**，写错会被静默跳过 |
| `exec.allow` | 白名单条目。**是否接受远程执行由这里决定**：不在白名单里的请求一律被拒，配置项 `execEnabled` 已废弃（旧文件里存在也不会报错，保存时会被清除） |
| `execAllow` | 允许运行的条目：`id`、`label`、`program`（绝对路径）、`args`、`workingDir`、`sha256`、`timeoutSec`、`maxMemoryMb`、`allowedPeers` |
| `stats.intervalMs` | 状态采样周期，服务端钳制在 500–30000 ms |
| `audio.*` | 码率、帧长、抖动缓冲目标深度 |

### 端口与防火墙

| 协议 | 端口 | 用途 |
| --- | --- | --- |
| TCP | 47810（可顺延） | 控制通道与文件数据，双向 TLS |
| UDP 组播 | 47811 | 设备发现（`239.255.42.99`，TTL=1） |
| UDP | 动态 | 音频流，端口在控制通道里协商 |

若设备互相看不见，先放行上面两个端口（或允许程序通过 Windows 防火墙）。

## 已知限制

- 仅支持 IPv4 局域网；不扫描 IPv6。
- 未实现 SecureOn 密码、SSH 远程登录或 AppleScript（参考图中的 SSH 字段未照搬，以避免保存明文凭据）。
- 扫描依赖 ARP 可见性；开启客户端隔离的 Wi-Fi 或跨 VLAN 的设备可能无法发现。
- 主机名通过 NetBIOS NBSTAT 获取；目标关闭 “NetBIOS over TCP/IP” 或防火墙阻止 137/UDP 时，名称显示 `—`。
- 在线状态依赖 ICMP Echo；目标阻止 Ping 或未填写 IP/域名时圆点保持灰色，即使设备实际在线。
- 界面语言可在 Preferences 下拉切换；英文为内置语言，其余语言从 `lang/` 加载。
- 已在 Windows 10 22H2（19045）+ MinGW-w64 15.2 下构建和验证。
- **互联网/跨 NAT 场景未做端到端验证**：设备发现依赖链路本地组播，跨网段需要手动添加设备或改走 VPN。
- **同一对端同时只传一个文件、一个音频流、一个脚本**：offer/ack、音频包与执行输出都没有携带任务 id，协议层无法区分并发任务，所以选择排队而不是并行。
- **音频是明文 UDP**：低延迟优先，没有加密也没有重传；同一局域网内的抓包者能听到内容。详见[安全说明](docs/netlink/05-security.md)。
- **端到端延迟未实测**：抖动缓冲、编码帧长、混音都是按 < 250 ms 的目标设计的，但没有两台真机的实测数据。
- 远程执行的界面（白名单对话框、脚本面板）只做了编译与文案验证，没有可自动化的点击路径，缺少交互截图。
- 远程电源需要目标进程拥有 `SeShutdownPrivilege`（以普通用户身份运行的进程可能无权关机）；取消依赖目标机上 Windows 自己的倒计时仍处于 pending 状态。倒计时由 Windows 管理，本程序退出不会撤销已经发出的关机。
- 设备的 CPU / 内存 / GPU 读数显示在设备详情的状态区；没有 WDDM GPU 计数器的机器不会显示 GPU 一项，而不是显示一个假的 0%。

## 开发记录

项目按功能里程碑提交：

1. 核心引擎、配置持久化、核心测试。
2. Win32 界面、编辑框、首选项、托盘菜单、UI 冒烟测试。
3. 局域网扫描性能优化、字体与视觉打磨、文档与截图。
4. 外挂语言文件与界面语言下拉选择（9 种语言 + 内置英文）。
5. 模态对话框打开时窗口闪烁白边的修复，四角像素回归断言。
6. 设备互联（NetLink）方案文档：需求分析、架构、执行计划、开源选型与两张架构图（尚未实现代码）。
7. 设备互联实现：发现 / 配对 / 状态推送 / 文件传输 / 音频混音 / 远程执行。
8. 远程电源控制（重启、关机、可取消的 30 秒倒计时）与设备详情页重排；补齐状态推送的服务端与订阅重试。
9. 版本号 1.1.0（文件版本 1.1.0.1），截图与文档同步更新。
