# 第三方组件许可登记

本文件随二进制与发布包分发。凡进入 `RemoteWakeUp.exe` 的第三方代码必须在此逐条登记：组件、版本、许可、来源、是否修改。

## 已引入

### mdns.h

| 项 | 内容 |
| --- | --- |
| 组件 | [mjansson/mdns](https://github.com/mjansson/mdns) 单头 mDNS / DNS-SD 库 |
| 文件 | `third_party/mdns/mdns.h` |
| 版本 | 抓取于 2026-11-18（上游 main 分支，API 稳定版 1.4.x 系列） |
| 许可 | **Public Domain**（上游声明：This library is put in the public domain; you can redistribute it and/or modify it without any restrictions） |
| 修改 | 无，原样保存 |
| 用途 | 设备发现的 mDNS/DNS-SD 兼容层（可选路径，主路径为自建 UDP 组播） |
| 体积 | 约 56 KB 源码，单翻译单元 |

### miniaudio

| 项 | 内容 |
| --- | --- |
| 组件 | [miniaudio](https://miniaud.io) 单头音频库（WASAPI 回环采集 + 播放 + 格式转换） |
| 文件 | `third_party/miniaudio/miniaudio.h` |
| 版本 | v0.11.26（2026-10-31），抓取于 2026-11-18 |
| 校验 | SHA-256 `6B376C7FBB1352BA1E0E432AB66069B335EA9405E45CB6C30B97EF0F3C9C3E0E` |
| 许可 | **MIT-0 / Public Domain**（上游双选，无署名义务） |
| 修改 | 无，原样保存 |
| 用途 | 系统声音回环采集（`ma_device_type_loopback`）、播放、以及到 48 kHz 立体声的格式与采样率转换 |
| 体积 | 4.16 MB 源码；只在一个翻译单元里定义 `MINIAUDIO_IMPLEMENTATION` |

### libopus

| 项 | 内容 |
| --- | --- |
| 组件 | [xiph/opus](https://github.com/xiph/opus) 音频编解码库 |
| 文件 | `third_party/opus/`（完整源码树，裁剪说明见 `VENDORED.md`） |
| 版本 | v1.5.2（官方 tag 源码包，4,183,352 字节），引入于 2026-11-18 |
| 许可 | **BSD-3-Clause**（见 `third_party/opus/COPYING`），无 GPL 成分 |
| 修改 | **只删不改**：删除 `.github` / `doc` / `tests` / `training` / `meson` 等构建与文档目录，源码未动。`configure.ac` 与 `*_sources.mk` 必须保留（上游 CMake 依赖它们读版本和源文件清单） |
| 用途 | 音频编码：48 kHz 立体声、20 ms 帧、DTX 与丢包隐藏 |
| 体积 | 约 3.2 MB 源码，静态库约 2.7 MB |

## 合规检查清单

发布前确认：

- [ ] 每个进入二进制的新第三方组件都在「已引入」有小节。
- [ ] 许可文本随包分发（`dist/.../LICENSES.md` 为本文件的副本）。
- [ ] 无 GPL / AGPL 代码进入链接产物。
- [ ] 修改过的第三方文件标注改动点与日期。
